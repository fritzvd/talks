// begint de tekening
function setup () {
  createCanvas(500, 500)

}

// draait meerdere keren per seconde
function draw () {
  // we tekenen een vierkant of "rect"angle.
  rect(10, 10, 10, 10)
}